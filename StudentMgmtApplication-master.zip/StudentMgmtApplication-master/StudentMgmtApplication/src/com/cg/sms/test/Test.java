package com.cg.sms.test;

import static org.junit.Assert.*;

public class Test {

	@org.junit.Test
	public void test() {
		fail("Not yet implemented");
	}

}
