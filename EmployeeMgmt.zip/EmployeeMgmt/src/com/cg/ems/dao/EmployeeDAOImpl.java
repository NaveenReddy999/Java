package com.cg.ems.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

import com.cg.ems.dto.Employee;
import com.cg.ems.dao.DataStore;
import com.cg.ems.dto.Employee;


public class EmployeeDAOImpl implements EmployeeDAO {
	Map<Integer,Employee> empMap;
	public EmployeeDAOImpl(){
		
		empMap = DataStore.createCollection();
	}

	@Override
	public int addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		int empid =	(int)(1000*Math.random());
		empMap.put(empid, employee);
			return empid;
	
	}

	@Override
	public Employee getEmployee(int empid) {
		// TODO Auto-generated method stub
		Employee emp = empMap.get(empid);
//		System.out.println(empMap.keySet());
		System.out.println(empMap.get(empid).getSalary());
		return empMap.get(empid);
	}

	@Override
	public Employee UpdateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		 empMap.put(employee.getEmployeeid(), employee);
			return employee;
	}

	@Override
	public ArrayList<Employee> getEmployeeList(String project) {
		// TODO Auto-generated method stub
		Collection <Employee> empList = empMap.values();
		ArrayList<Employee> employees = new ArrayList<>();
		
		for(Employee s : empList){
			if(s.getProject().equals(project)){
				employees.add(s);
			}
		}
		return employees;
		}

}
