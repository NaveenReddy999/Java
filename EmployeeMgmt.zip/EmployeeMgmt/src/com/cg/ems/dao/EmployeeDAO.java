package com.cg.ems.dao;

import java.util.ArrayList;

import com.cg.ems.dto.Employee;
public interface EmployeeDAO {
	public int addEmployee(Employee employee);
	public Employee getEmployee(int empid);
	public Employee UpdateEmployee(Employee employee);
	public ArrayList<Employee> getEmployeeList(String project);

}
