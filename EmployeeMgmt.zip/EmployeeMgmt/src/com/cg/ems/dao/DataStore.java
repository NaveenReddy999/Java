package com.cg.ems.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.ems.dto.Employee;

public class DataStore {
	private static Map<Integer,Employee> employees;
	public static   Map<Integer,Employee> createCollection(){
	if(employees==null)
		employees= new HashMap<>();
	return employees;
}

}
