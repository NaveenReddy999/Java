package com.cg.ems.service;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ems.dto.Employee;

import com.cg.ems.dao.EmployeeDAO;
import com.cg.ems.dao.EmployeeDAOImpl;
import com.cg.ems.exception.EmployeeException;




public class EmployeeServiceImpl implements EmployeeService {
	EmployeeDAO dao;
	public EmployeeServiceImpl(){
		dao = new EmployeeDAOImpl();
	}

	@Override
	public int addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		int empid = dao.addEmployee(employee);
		return empid;
	}

	@Override
	public Employee getEmployee(int empid) {
		// TODO Auto-generated method stub
		return  dao.getEmployee(empid);
	}

	@Override
	public Employee UpdateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		 return dao.UpdateEmployee(employee);
	}

	public Employee ValidateDetails(Employee ed)
			throws EmployeeException {

			if(
					 validateName(ed.getName())  )
			return ed;
			else
		return null;
	}

	@Override
	public ArrayList<Employee> getEmployeeList(String project) {
		// TODO Auto-generated method stub
		return dao.getEmployeeList(project);
	}
	public boolean validateName(String name) throws EmployeeException {
		if(name==null)
			throw new EmployeeException("name can not be null");
		Pattern pat = Pattern.compile("[A-Z][a-z]{3,12}");
		Matcher mat= pat.matcher(name);
		return mat.matches();
	}


}
