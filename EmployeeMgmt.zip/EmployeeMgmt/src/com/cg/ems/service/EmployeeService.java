package com.cg.ems.service;

import java.util.ArrayList;

import com.cg.ems.dto.Employee;

import com.cg.ems.exception.EmployeeException;

public interface EmployeeService {
	public int addEmployee(Employee employee);
	public Employee getEmployee(int empid);
	public Employee UpdateEmployee(Employee employee);
	public ArrayList<Employee> getEmployeeList(String project);
	
	public Employee ValidateDetails(Employee ed)throws EmployeeException;
	public boolean validateName(String name) throws EmployeeException;

}
