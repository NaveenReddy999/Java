package com.cg.ems.test;

import org.junit.Test;

import junit.framework.Assert;


//import com.cg.ems.exception;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.EmployeeService;
import com.cg.ems.service.EmployeeServiceImpl;

public class TestClass {

	@Test(expected=Exception.class)
	public void test_ValidateName_null() throws EmployeeException{
		EmployeeService service=new EmployeeServiceImpl();
		service.validateName(null);
	}
	
	@Test
	public void test_validateName_v1() throws EmployeeException{
	
		String name="Aete121";
		EmployeeService service=new EmployeeServiceImpl();
		boolean result= service.validateName(name);
		Assert.assertEquals(false,result);
	}
	@Test
	public void test_validateName_v2() throws EmployeeException{
	
		String name="Amita";
		EmployeeService service=new EmployeeServiceImpl();
		boolean result= service.validateName(name);
		Assert.assertEquals(true,result);
	}
	@Test
	public void test_validateName_v3() throws EmployeeException{
	
		String name="amita";
		EmployeeService service=new EmployeeServiceImpl();
		boolean result= service.validateName(name);
		Assert.assertEquals(false,result);
	}
	
	
}