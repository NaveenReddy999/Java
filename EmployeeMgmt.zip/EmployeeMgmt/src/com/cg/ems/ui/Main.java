package com.cg.ems.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.ems.dto.Employee;

import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.EmployeeService;
import com.cg.ems.service.EmployeeServiceImpl;



public class Main {
	public static void main(String []args) throws EmployeeException{
	
		EmployeeService service = new EmployeeServiceImpl();
		Scanner sc = new Scanner(System.in);
	
		Employee ed= new Employee();
		//do{
		//System.out.println("Enter Employee name ");
	//	String name= sc.next();

//		ed.setName(name);
//		try {
//			if( service.ValidateDetails(ed)!=null)
//				break;
//			else
//				System.out.println("Invalid details entered...");
//		} catch (EmployeeException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		}while(true);
		//int empid = service.addEmployee(ed);
		//System.out.println("Record inserted..."+empid);
		
		
		
		
		int ch = 0;
		
		do{
		System.out.println("1. Add Employee ");
		System.out.println("2. Display employee details");
		System.out.println("3. Update details");
		System.out.println("4. Display Employee list");
		System.out.println("Enter your choice");
		ch = sc.nextInt();
		switch(ch){
		
		case 1:
			
				
	    Employee emp = new Employee();
	    do{
			//System.out.println("Enter Employee name ");
			//String name1= sc.next();
	    	System.out.println("Enter name :");
			String name1=sc.next();
			
			System.out.println("Enter Salary :");
			float sal =sc.nextFloat();
			
			System.out.println("Enter project :");
			String proj =sc.next();
			
			System.out.println("Enter designation :");
			String desig =sc.next();

	  
		emp.setName(name1);		
		emp.setSalary(sal);
		emp.setDesignation(desig);
		emp.setProject(proj);
		  try {
				if( service.ValidateDetails(emp)!=null)
					break;
				else
					System.out.println("Invalid details entered...");
			} catch (EmployeeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}while(true);
		int id = service.addEmployee(emp);
		System.out.println("employee record added . . "+id);
		break;
		
		case 2:
			System.out.println("Enter Employee id: ");
			int empid = sc.nextInt();
			Employee emp1 = service.getEmployee(empid);
			if(emp1 == null){
				System.err.println("Record not found . .");
			}
			else{
			System.out.println(emp1.getName());
			System.out.println(emp1.getSalary());
			System.out.println(emp1.getDesignation());
			System.out.println(emp1.getProject());
			}
			break;
			
		case 3:
			System.out.println("Enter Employee id:");
			empid = sc.nextInt();
			
			emp= service.getEmployee(empid);
			if(emp==null)
				System.err.println("Record not found");
			else{
				System.out.println("Enter new Salary: ");
				float salry =  sc.nextFloat();
				emp.setSalary(salry);
				emp = service.UpdateEmployee(emp);
				System.out.println("Record Updated: ");
				
				System.out.println(emp.getName());
				System.out.println(emp.getSalary());
			}
			break;
			
		case 4:
			System.out.println("Enter Project name ");
			 String proj= sc.next();
			ArrayList<Employee> list= service.getEmployeeList(proj);
			
			if(list.size()==0)
				System.out.println("No employee is enrolled to this record");
			else{
				for(Employee s: list){
					System.out.println(s.getName()+" "+ s.getDesignation());
					
				}
			}
	
	}
		
		}while(ch!=5);

}
}
